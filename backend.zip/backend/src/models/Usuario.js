// backend/src/models/Usuario.js
const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');
const bcrypt = require('bcrypt');

const Usuario = sequelize.define('Usuario', {
  id: {
    type: DataTypes.UUID, // Identificador unico universal
    defaultValue: DataTypes.UUIDV4,  // Generacion automatica
    primaryKey: true      // Clave primaria
  },
  username: {
    type: DataTypes.STRING(50),
    unique: true,
    allowNull: false  //Obligatorio 
  },
  password_hash: {
    type: DataTypes.STRING(255),
    allowNull: false
  },
  role: {
    type: DataTypes.ENUM('ADMIN', 'RESPONSABLE'),
    allowNull: false
  },
  nombre: {
    type: DataTypes.STRING(100)
  },
  apellidos: {
    type: DataTypes.STRING(100)
  },
  email: {
    type: DataTypes.STRING(100),
    unique: true,
    allowNull: false,
    validate: {
      isEmail: true
    }
  },
  movil: {
    type: DataTypes.STRING(20)
  },
  avatar: {
    type: DataTypes.TEXT
  },
  activo: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  ultimo_acceso: {
    type: DataTypes.DATE
  }
}, {
  tableName: 'usuarios',
  timestamps: true,               // Sequelize se encarga de añadir automaticamente created_at y updated_at
  createdAt: 'created_at',
  updatedAt: 'updated_at'
});

// Metodo para comparar password
Usuario.prototype.comparePassword = async function(password) {
  return await bcrypt.compare(password, this.password_hash);
};

// Hook para hashear password antes de crear
Usuario.beforeCreate(async (usuario) => {
  if (usuario.password_hash) {
    usuario.password_hash = await bcrypt.hash(usuario.password_hash, 10); // Factor de coste 10 (2¹⁰)
  }
});

module.exports = Usuario;
