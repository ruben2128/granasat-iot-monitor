// backend/src/server.js
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const { testConnection } = require('./config/database');

// Importar rutas
const authRoutes = require('./routes/authRoutes');

// Crear app Express
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Ruta de prueba
app.get('/', (req, res) => {
  res.json({
    message: 'API TFG IoT funcionando',
    version: '1.0.0',
    timestamp: new Date()
  });
});

// Ruta health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    database: 'connected',
    uptime: process.uptime()
  });
});

// RUTAS DE LA API
app.use('/api/auth', authRoutes);

// Middleware para rutas no encontradas
app.use((req, res) => {
  res.status(404).json({
    error: 'Ruta no encontrada',
    path: req.path
  });
});

// Puerto
const PORT = process.env.PORT || 3001;

// Iniciar servidor
async function startServer() {
  try {
    // Probar conexión a BD
    const conexBBDD = await testConnection();
    
    if (!conexBBDD) {
      console.error('No se pudo conectar a la base de datos');
      process.exit(1);
    }
    
    // Iniciar servidor
    app.listen(PORT, () => {
      console.log(`Servidor corriendo en http://localhost:${PORT}`);
      console.log(`Entorno: ${process.env.NODE_ENV}`);
      console.log(`\n Rutas disponibles:`);
      console.log(`   POST   /api/auth/register`);
      console.log(`   POST   /api/auth/login`);
      console.log(`   GET    /api/auth/me`);
    });
  } catch (error) {
    console.error(' Error iniciando servidor:', error);
    process.exit(1);
  }
}

startServer();